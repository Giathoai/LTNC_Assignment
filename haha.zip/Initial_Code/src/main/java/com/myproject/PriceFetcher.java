package com.myproject;

import java.util.List;

public interface PriceFetcher {
    List<StockPrice> fetch();
}

